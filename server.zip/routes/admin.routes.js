const { AdminAllUsers, getAdminProducts } = require("../controller/admin.controller")

const router = require("express").Router()
router
    .get("/allUsers-admin", AdminAllUsers)
    .get("/getProduct-admin", getAdminProducts)

module.exports = router